package com.t2b.api.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.t2b.api.auth.entity.User;

/**
 * @author Nataraj Gnanavadivel
 *
 */
public interface UserRepository extends JpaRepository<User, Long> {

   User findByUserEmailAddress(String userEmailAddress);
}
