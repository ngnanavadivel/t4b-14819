package com.t2b.api.auth.web;

import java.net.URI;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ser.std.MapSerializer;
import com.t2b.api.auth.entity.User;
import com.t2b.api.auth.repository.UserRepository;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@RestController
public class UserController {

   @Value("${token.generation.endpoint}")
   String                        tokenGenerationEndpoint;

   @Value("${token.publickey.endpoint}")
   String                        tokenPublicKeyEndpoint;

   private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(11);

   @Autowired
   UserRepository                repo;

   @Autowired
   private RestTemplate          template;

   @PostMapping("/user")
   public Long createUser(@RequestBody User user, HttpServletResponse response) {
      user.setSecret(encoder.encode(user.getSecret()));
      User saved = repo.save(user);
      if (saved.getId() > 0) {
         stuffTokenAsCookie(response, saved.getUserEmailAddress());
      }
      return saved.getId();
   }

   @PostMapping("/user/authenticate")
   public Boolean isValidUser(@RequestBody User user, HttpServletResponse response) {
      User fromDb = repo.findByUserEmailAddress(user.getUserEmailAddress());
      boolean matches = encoder.matches(user.getSecret(), fromDb.getSecret());
      if (matches) {
         stuffTokenAsCookie(response, user.getUserEmailAddress());
      }
      return matches;
   }

   private String getToken(String username, Map<String, String> customClaims) {
      // Let's create a Membership for the member.
      Map<String, Object> pathParams = new LinkedHashMap<>();
      pathParams.put("username", username);
      // Stuff Path Parameters
      URI uri = UriComponentsBuilder.fromUriString(this.tokenGenerationEndpoint)
         .buildAndExpand(pathParams)
         .toUri();
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      HttpEntity<?> requestBody = new HttpEntity<Object>(customClaims, headers);
      String token = template.postForObject(uri, requestBody, String.class);
      System.out.println("TOKEN ::" + token);
      return token;
   }

   private void stuffTokenAsCookie(HttpServletResponse response, String username) {
      Cookie cookie = new Cookie("x-auth-token", getToken(username, Collections.emptyMap()));
      cookie.setHttpOnly(true);
      // cookie.setSecure(true);
      response.addCookie(cookie);
   }
}
