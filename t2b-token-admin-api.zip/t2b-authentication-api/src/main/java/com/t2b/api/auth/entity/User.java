package com.t2b.api.auth.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
public class User extends AuditableEntity {

   private static final long serialVersionUID = -8818284231649030200L;

   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   private Long              id;

   @Column
   @NotNull
   private String            userEmailAddress;

   @Column
   @NotNull
   private String            secret;

   @Column
   private boolean           locked           = false;

   public Long getId() {
      return id;
   }

   public void setId(Long id) {
      this.id = id;
   }

   public String getUserEmailAddress() {
      return userEmailAddress;
   }

   public void setUserEmailAddress(String userEmailAddress) {
      this.userEmailAddress = userEmailAddress;
   }

   public String getSecret() {
      return secret;
   }

   public void setSecret(String secret) {
      this.secret = secret;
   }

   public boolean isLocked() {
      return locked;
   }

   public void setLocked(boolean locked) {
      this.locked = locked;
   }
}
