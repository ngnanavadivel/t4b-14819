package com.t2b.api.payment.error;

import org.springframework.http.HttpStatus;

/**
 * @author Nataraj Gnanavadivel
 *
 */
public class T2BApiException extends RuntimeException {

   private static final long serialVersionUID = 5837637113530781341L;

   private HttpStatus        status           = HttpStatus.INTERNAL_SERVER_ERROR;

   public T2BApiException() {
      super();
   }

   public T2BApiException(HttpStatus status, String message) {
      super(message);
      this.status = status;
   }

   public T2BApiException(HttpStatus status, String message, Throwable cause) {
      super(message, cause);
      this.status = status;
   }

   public HttpStatus getStatus() {
      return status;
   }

   public void setStatus(HttpStatus status) {
      this.status = status;
   }
}
