package com.t2b.api.payment.web;

import static com.t2b.api.payment.common.LogMessageBuilder.logMsg;

import java.math.BigDecimal;
import java.net.URI;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Charge;
import com.stripe.model.Refund;
import com.stripe.model.Token;
import com.t2b.api.payment.common.Messages;
import com.t2b.api.payment.error.T2BApiException;
import com.t2b.entity.MembershipDTO;
import com.t2b.entity.MembershipTransactionDTO;
import com.t2b.entity.PaymentDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@RestController
@Slf4j
public class PaymentsController {

   private static final String INITIATED                    = "INITIATED";

   private static final String CHARGE_DESC_MEMBERSHIP_PYMNT =
                                                            "T2B Membership Plan Subscription";

   private static final String USD                          = "usd";

   private static final String SOURCE                       = "source";

   private static final String DESCRIPTION                  = "description";

   private static final String CURRENCY                     = "currency";

   private static final String AMOUNT                       = "amount";

   public static void main1(String[] args) throws StripeException {
      Stripe.apiKey = "pk_test_5ZHxesbXfzCkaU1LwDj0LCd2";
      Map<String, Object> tokenParams = new HashMap<>();
      Map<String, Object> cardParams = new HashMap<>();
      cardParams.put("number", "4242424242424242");
      cardParams.put("exp_month", 10);
      cardParams.put("exp_year", 2019);
      cardParams.put("cvc", "314");
      tokenParams.put("card", cardParams);
      Token tkn = Token.create(tokenParams);
      System.out.println(tkn.toJson());
   }

   @Autowired
   private RestTemplate template;

   @Value("${stripe.private.apikey}")
   private String       stripeApiKey;

   @Value("${api.membership.creation.endpoint}")
   private String       membershipCreationEndpoint;

   @Value("${api.membership.transaction.creation.endpoint}")
   private String       membershipTxnCreationEndpoint;

   @Value("${api.membership.transaction.status.update.endpoint}")
   private String       membershipTxnUpdateEndpoint;

   @PostMapping(path = "/charge")
   public MembershipDTO charge(@Valid @RequestBody PaymentDTO payment) throws StripeException {

      log.info(logMsg(Messages.MAKING_PAYMENT_FOR_MEMBERSHIP, payment));
      // STEP 1. Create a MembershipTransaction Record with INITIATED status.
      MembershipTransactionDTO txn = null;
      try {
         txn = createMembershipTransaction(payment);
         log.info(String
            .format("Step 1 - Membership Transaction Record created with status INITIATED for member with ID %d and plan ID %d",
                    payment.getMemberId(),
                    payment.getPlanId()));
      }
      catch (Exception e) {
         String errorMsg =
                         "Failure @ Step 1. (Initial Membership Transaction record creation itself failed)";
         log.error(errorMsg);
         throw new T2BApiException(HttpStatus.INTERNAL_SERVER_ERROR, errorMsg, e);
      }

      // STEP 2. Charge the customer using Stripe API.
      boolean paymentSucceeded = false;
      Charge charge = null;
      boolean exceptionCaughtWhilePayment = false;
      Throwable paymentException = null;
      try {
         charge = makeStripeCharge(payment);
         paymentSucceeded =
                          charge.getPaid() && "succeeded".equalsIgnoreCase(charge.getStatus());
      }
      catch (Exception e) {
         exceptionCaughtWhilePayment = true;
         paymentException = e;
      }
      if (paymentSucceeded) {
         log.info(String
            .format("Step 2 - Stripe charge creation succeeded with charge ID %s for member with ID %d and plan ID %d",
                    charge.getId(),
                    payment.getMemberId(),
                    payment.getPlanId()));
         // Step 3. Update Membership Transaction Record with status 'PAYMENT_SUCCEEDED'.
         txn = updateTransactionStatus(txn.getId(), "PAYMENT_SUCCEEDED");
         log.info(String
            .format("Step 3 - Membership Transaction record with ID %d is updated with status 'PAYMENT_SUCCEEDED' for member with ID %d and plan ID %d",
                    txn.getId(),
                    payment.getMemberId(),
                    payment.getPlanId()));
      }
      else {
         // Step 3. Update Membership Transaction Record with status 'PAYMENT_FAILED'.
         txn = updateTransactionStatus(txn.getId(), "PAYMENT_FAILED");
         log.info(String
            .format("Step 3 - Membership Transaction record with ID %d is updated with status 'PAYMENT_FAILED' for member with ID %d and plan ID %d",
                    txn.getId(),
                    payment.getMemberId(),
                    payment.getPlanId()));

         if (exceptionCaughtWhilePayment) {
            String errorMsg =
                            "Failure @ Step 2. (Stripe Charge creation / Payment attempt has failed)";
            log.error(errorMsg);
            throw new T2BApiException(HttpStatus.INTERNAL_SERVER_ERROR,
                                      errorMsg,
                                      paymentException);
         }
         else {
            String errorMsg =
                            "Failure @ Step 2. (Stripe Charge creation / Payment attempt has failed silently with status : "
                               + charge.getStatus();
            log.error(errorMsg);
            throw new T2BApiException(HttpStatus.INTERNAL_SERVER_ERROR, errorMsg);
         }
      }

      // Step 4. Create a Membership
      MembershipDTO response = null;
      try {
         response = createMembership(payment);
         log.info(String
            .format("Step 4 - Membership created successfully for member with ID %d and plan ID %d",
                    payment.getMemberId(),
                    payment.getPlanId()));

      }
      catch (Exception t) {
         String errorMsg = "Failure @ Step 4. (Membership creation has failed)";
         log.error(errorMsg);
         throw new T2BApiException(HttpStatus.INTERNAL_SERVER_ERROR, errorMsg, t);
      }
      return response;
   }

   /**
    * @param payment
    * @return
    */
   private MembershipDTO createMembership(PaymentDTO payment) {
      MembershipDTO response;
      // Let's create a Membership for the member.
      Map<String, Object> pathParams = new LinkedHashMap<>();
      pathParams.put("memberId", payment.getMemberId());
      pathParams.put("planId", payment.getPlanId());
      // Stuff Path Parameters
      URI uri = UriComponentsBuilder.fromUriString(membershipCreationEndpoint)
         .buildAndExpand(pathParams)
         .toUri();
      response = template.postForObject(uri, null, MembershipDTO.class);
      return response;
   }

   /**
    * @param payment
    * @return
    */
   private MembershipTransactionDTO createMembershipTransaction(PaymentDTO payment) {
      MembershipTransactionDTO txn = new MembershipTransactionDTO();
      String transactionTypeCode = "TXN_MEMBERSHIP_CREATION";
      txn.setTransactionTypeCode(transactionTypeCode);
      txn.setMemberId(payment.getMemberId());
      txn.setMembershipPlanId(payment.getPlanId());
      // Payment DTO has everything represented in cents. Not in Dollars.
      // Thats a Stripe requirement. we can't charge stripe in decimals.
      txn.setTransactionAmount(new BigDecimal(payment.getAmount() / 100));
      txn.setTransactionCurrency(USD);
      txn.setTransactionDate(LocalDateTime.now());
      txn.setTransactionStatus(INITIATED);
      HttpEntity<MembershipTransactionDTO> requestBody = new HttpEntity<>(txn);
      return template.postForObject(membershipTxnCreationEndpoint,
                                    requestBody,
                                    MembershipTransactionDTO.class);
   }

   /**
    * @param charge
    * @return
    * @throws StripeException
    */
   private Refund createRefund(Charge charge) throws StripeException {
      Refund refund;
      Map<String, Object> refundParams = new HashMap<>();
      refundParams.put("charge", charge.getId());
      refund = Refund.create(refundParams);
      return refund;
   }

   /**
    * @param payment
    * @return
    * @throws StripeException
    */
   private Charge makeStripeCharge(PaymentDTO payment) throws StripeException {
      Charge charge;
      Stripe.apiKey = stripeApiKey;
      Map<String, Object> params = new HashMap<>();
      // !!IMPORTANT!! The amount for that plan should
      // be obtained from the db for security sake.
      params.put(AMOUNT, payment.getAmount());
      params.put(CURRENCY, USD);
      params.put(DESCRIPTION, CHARGE_DESC_MEMBERSHIP_PYMNT);
      params.put(SOURCE, payment.getToken());
      charge = Charge.create(params);
      return charge;
   }

   private MembershipTransactionDTO updateTransactionStatus(Long transactionId,
                                                            String status) {
      Map<String, Object> pathParams = new LinkedHashMap<>();
      pathParams.put("txnId", transactionId);
      pathParams.put("transactionStatus", status);
      // Stuff Path Parameters
      URI uri = UriComponentsBuilder.fromUriString(membershipTxnUpdateEndpoint)
         .buildAndExpand(pathParams)
         .toUri();
      return template.postForObject(uri, null, MembershipTransactionDTO.class);
   }
}
