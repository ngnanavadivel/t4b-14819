package com.t2b.api.payment.common;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class LogMessageBuilder {

   public static String logMsg(Messages message, Object... args) {
      return String.format(message.value(), args);
   }
}
