package com.t2b.api.payment.common;

/**
 * @author Nataraj Gnanavadivel
 *
 */
public enum Messages {
      MAKING_PAYMENT_FOR_MEMBERSHIP("Making a payment for Membership with values %s");

   private String message;

   Messages(String message) {
      this.message = message;
   }

   public String value() {
      return this.message;
   }
}
