package com.t2b.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MembershipTransactionDTO extends AuditableDTO {

   private static final long serialVersionUID = 1L;

   private Long              id;

   private String            transactionTypeCode;

   private LocalDateTime     transactionDate;

   private Long              memberId;

   private Long              membershipPlanId;

   private BigDecimal        transactionAmount;

   private String            transactionCurrency;

   private String            transactionStatus;
}
