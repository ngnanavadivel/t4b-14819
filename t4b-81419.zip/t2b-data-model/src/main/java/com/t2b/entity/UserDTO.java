package com.t2b.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UserDTO extends AuditableDTO {

   private static final long serialVersionUID = -8818284231649030200L;

   private Long              id;

   private String            userEmailAddress;

   private String            secret;

   private boolean           locked           = false;
}
