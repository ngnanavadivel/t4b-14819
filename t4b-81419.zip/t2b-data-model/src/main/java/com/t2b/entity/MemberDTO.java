package com.t2b.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MemberDTO extends AuditableDTO {

   private static final long serialVersionUID = 2716356425907074920L;

   private Long              id;

   private String            firstName;

   private String            lastName;

   private String            emailAddress;

   private String            addressLine1;

   private String            addressLine2;

   private String            city;

   private String            state;

   private String            zipCode;

   private String            phoneNumber;

   private boolean           isCancel;

   private String            gender;
}
