package com.t2b.entity;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MembershipDTO extends AuditableDTO {

   private static final long serialVersionUID = 4591375810571419180L;

   private Long              id;

   private LocalDateTime     startDate;

   private LocalDateTime     endDate;

   private boolean           cancelled        = false;

   private Long              memberId;

   private Long              membershipPlanId;
}
