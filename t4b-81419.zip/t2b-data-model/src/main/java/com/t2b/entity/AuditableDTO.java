package com.t2b.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
public abstract class AuditableDTO implements Serializable {

   private static final long serialVersionUID = 1L;

   private Date createdAt;

   private Date updatedAt;
}
