package com.t2b.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class MembershipPlanDTO extends AuditableDTO {

   private static final long serialVersionUID = 3013996932401904612L;

   private Long              membershipPlanId;

   private String            planName;

   private String            planDescription;

   private Double            planAmount;
}
