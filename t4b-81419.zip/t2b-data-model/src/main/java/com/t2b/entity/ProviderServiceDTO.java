package com.t2b.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ProviderServiceDTO extends AuditableDTO {

   private static final long serialVersionUID = 2716356425907074921L;

   private Long              id;

   private String            name;

   private String            description;

   private Long            typeCodeId;
   
   private Integer            discount;
   
   private String            typeCodeName;

}
