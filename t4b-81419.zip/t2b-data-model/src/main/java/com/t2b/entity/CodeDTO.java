package com.t2b.entity;

import java.math.BigDecimal;

import lombok.Data;

/**
 * @author Hukm Chand
 *
 */
@Data
public class CodeDTO {

   private Long   id;

   private String   name;

   private String description;

   private boolean isCancel;
   
   private Long   codeTypeId;
   
   
}
