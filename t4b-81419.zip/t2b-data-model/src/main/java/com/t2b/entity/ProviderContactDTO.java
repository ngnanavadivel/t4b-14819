package com.t2b.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ProviderContactDTO extends AuditableDTO {

   private static final long serialVersionUID = 2716356425907074921L;

   private Long              id;

   private String            firstName;
   
   private String            lastName;

   private String            emailAddress;

   private String            phoneNumber;
   
   private String            contactTitle;
   
   private boolean           isPrimary;

}
