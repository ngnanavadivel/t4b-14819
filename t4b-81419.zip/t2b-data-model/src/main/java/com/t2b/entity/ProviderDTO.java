package com.t2b.entity;

import java.util.List;
import java.util.Set;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ProviderDTO extends AuditableDTO {

   private static final long serialVersionUID = 2716356425907074921L;

   private Long              id;

   private String            providerName;

   private String            emailAddress;

   private String            addressLine1;

   private String            addressLine2;

   private String            city;

   private String            state;

   private String            zipCode;

   private String            phoneNumber;
   
   private Long            typeCodeId;
   private String            typeCodeName;
   
   private boolean           isCancel;
   
   private List<ProviderContactDTO> contacts;
   private List<ProviderServiceDTO> services;

}
