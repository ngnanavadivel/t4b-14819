package com.t2b.entity;

import java.math.BigDecimal;

import lombok.Data;

/**
 * @author Nataraj Gnanavadivel, Hukm Chand
 *
 */
@Data
public class PaymentDTO {

   private Long   memberId;

   private Long   planId;

   private Long amount;

   private String token;
}
