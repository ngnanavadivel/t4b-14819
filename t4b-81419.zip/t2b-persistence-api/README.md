# t2b-persistence-api
API that does CRUD operations on Ticket to Beauty domain entities.
