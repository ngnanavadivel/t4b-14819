package com.t2b.api.persistence.web;

import static com.t2b.api.persistence.common.LogMessageBuilder.logMsg;
import static com.t2b.api.persistence.error.ErrorMesssageBuilder.errMsg;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.t2b.api.persistence.common.Messages;
import com.t2b.api.persistence.entity.Code;
import com.t2b.api.persistence.entity.MembershipPlan;
import com.t2b.api.persistence.entity.Provider;
import com.t2b.api.persistence.entity.ProviderContact;
import com.t2b.api.persistence.entity.ProviderService;
import com.t2b.api.persistence.error.Errors;
import com.t2b.api.persistence.error.T2BApiException;
import com.t2b.api.persistence.repository.CodeRepository;
import com.t2b.api.persistence.repository.ProviderContactRepository;
import com.t2b.api.persistence.repository.ProviderRepository;
import com.t2b.api.persistence.repository.ProviderServiceRepository;
import com.t2b.api.persistence.repository.ProviderRepository;
import com.t2b.entity.ProviderContactDTO;
import com.t2b.entity.ProviderDTO;
import com.t2b.entity.ProviderServiceDTO;
import com.t2b.entity.ProviderDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Hukmchand
 *
 */
@RestController
@Slf4j
public class ProviderController {

   @Autowired
   private ModelMapper        mapper;

   @Autowired
   private ProviderRepository providerRepo;
   
   @Autowired
   private ProviderContactRepository providerContactRepo;
   
   @Autowired
   private ProviderServiceRepository providerServiceRepo;
   
   @Autowired
   private ProviderServiceController providerServiceController;
   
   @Autowired
   private ProviderContactController providerContactController;

   @Autowired
   private CodeRepository     codeRepo;

   @PostMapping(path = "/provider")
   public ProviderDTO createProvider(@Valid @RequestBody ProviderDTO providerDto) {
      log.info(logMsg(Messages.CREATING_PROVIDER, providerDto));
      Provider entityToBeSaved = convertToEntity(providerDto);
      Optional<Code> code = codeRepo.findById(providerDto.getTypeCodeId());
      if (code.isPresent()) {
         entityToBeSaved.setTypeCode(code.get());
         ProviderDTO resultDto = convertToDTO(providerRepo.save(entityToBeSaved));
         log.info(logMsg(Messages.CREATED_PROVIDER_SUCCESSFULLY, resultDto));
         
         
         for(ProviderServiceDTO providerServiceDto:providerDto.getServices())
         {
            providerServiceController.createProviderService(entityToBeSaved.getId(), providerServiceDto);
            
         }
         
         for(ProviderContactDTO providerServiceDto:providerDto.getContacts())
         {
            providerContactController.createProviderContact(entityToBeSaved.getId(), providerServiceDto);
            
         }
         
         
         return resultDto;
      }
      else {
         throw new T2BApiException(HttpStatus.NOT_FOUND,
                                   errMsg(Errors.CODE_DOESNOT_EXIST, providerDto.getTypeCodeId()));
      }
      
    
      
      
     
      
   }

   @DeleteMapping(path = "/provider/{providerId}")
   public ResponseEntity<Object> deleteProvider(@PathVariable Long providerId) {
      log.info(logMsg(Messages.DELETING_PROVIDER, providerId));
      return providerRepo.findById(providerId).map(provider -> {
         providerRepo.delete(provider);
         log.info(logMsg(Messages.DELETED_PROVIDER_SUCCESSFULLY, providerId));
         return ResponseEntity.ok().build();
      })
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.PROVIDER_DOESNOT_EXIST,
                                                       providerId)));
   }

   @GetMapping(path = "/provider/{providerId}")
   public ProviderDTO findProvider(@PathVariable Long providerId) {
      log.info(logMsg(Messages.FINDING_PROVIDER_BY_ID, providerId));
      Provider foundProvider = providerRepo.findById(providerId)
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.PROVIDER_DOESNOT_EXIST,
                                                       providerId)));
      ProviderDTO foundDto =  convertToDTO(foundProvider);
      if (foundProvider != null) {
      
         List<ProviderContactDTO> contacts = new ArrayList<ProviderContactDTO>();
         foundDto.setContacts(contacts);
         for (ProviderContact proContact : providerContactRepo.findAllByProviderId(providerId)) {
          
            contacts.add(convertContactToDTO(proContact));
         }
         
         List<ProviderServiceDTO> services = new ArrayList<ProviderServiceDTO>();
         foundDto.setServices(services);
         for (ProviderService proService : providerServiceRepo.findAllByProviderId(providerId)) {
            proService.getServiceTypeCode().getName();
            services.add(convertServiceToDTO(proService));
         }
      }
      log.info(logMsg(Messages.FOUND_PROVIDER, providerId, foundDto));
      return foundDto;
   }

   @GetMapping("/provider")
   public Page<ProviderDTO> getAll(Pageable pageable) {
      log.info(logMsg(Messages.FINDING_ALL_PROVIDERS));
      Page<ProviderDTO> pageOfProviderDTOs = null;
      Page<Provider> entitiesFound = providerRepo.findAll(pageable);
      if (entitiesFound != null) {
         pageOfProviderDTOs = entitiesFound.map(this::convertToDTO);
      }
      log.info(logMsg(Messages.FOUND_PROVIDERS,
                      (pageOfProviderDTOs != null ? pageOfProviderDTOs.getNumberOfElements()
                                                  : 0)));
      return pageOfProviderDTOs;
   }

   @PutMapping(path = "/provider/{providerId}")
   public ProviderDTO updateProvider(@PathVariable Long providerId,
                                     @RequestBody ProviderDTO providerDto) {
      log.info(logMsg(Messages.UPDATING_PROVIDER, providerId, providerDto));
      Provider modifiedEntity = providerRepo.findById(providerId).map(provider -> {
         provider.setProviderName(providerDto.getProviderName());
         provider.setEmailAddress(providerDto.getEmailAddress());
         provider.setPhoneNumber(providerDto.getPhoneNumber());
         provider.setAddressLine1(providerDto.getAddressLine1());
         provider.setAddressLine2(providerDto.getAddressLine2());
         provider.setCity(providerDto.getCity());
         provider.setState(providerDto.getState());
         provider.setZipCode(providerDto.getZipCode());
         provider.setCancel(providerDto.isCancel());
         return provider;
      })
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.PROVIDER_DOESNOT_EXIST,
                                                       providerId)));
      ProviderDTO updatedDto = convertToDTO(providerRepo.save(modifiedEntity));
      log.info(logMsg(Messages.UPDATED_PROVIDER_SUCCESSFULLY, updatedDto));
      return updatedDto;
   }

   private ProviderDTO convertToDTO(@Valid Provider provider) {
      return mapper.map(provider, ProviderDTO.class);
   }

   private ProviderContactDTO convertContactToDTO(@Valid ProviderContact providerContact) {
      return mapper.map(providerContact, ProviderContactDTO.class);
   }
   
   private ProviderServiceDTO convertServiceToDTO(@Valid ProviderService providerService) {
      return mapper.map(providerService, ProviderServiceDTO.class);
   }

   /**
    * @param providerDto
    * @return
    */
   private Provider convertToEntity(@Valid ProviderDTO providerDto) {
      return mapper.map(providerDto, Provider.class);
   }
}
