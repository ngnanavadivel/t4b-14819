package com.t2b.api.persistence.common;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class LogMessageBuilder {

   public static String logMsg(Messages logMessage, Object... args) {
      return String.format(logMessage.value(), args);
   }
}
