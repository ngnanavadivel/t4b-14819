package com.t2b.api.persistence.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.t2b.api.persistence.entity.MembershipTransaction;

/**
 * @author Nataraj Gnanavadivel
 *
 */
public interface MembershipTransactionRepository
      extends JpaRepository<MembershipTransaction, Long> {

   Page<MembershipTransaction> findAllByMemberId(Long memberId, Pageable pageable);

   @Modifying
   @Query("update MembershipTransaction txn set txn.transactionStatus = :txnStatus where txn.id = :id")
   int updateTransactionStatus(@Param("id") Long id, @Param("txnStatus") String status);

}
