package com.t2b.api.persistence.web;

import static com.t2b.api.persistence.common.LogMessageBuilder.logMsg;
import static com.t2b.api.persistence.error.ErrorMesssageBuilder.errMsg;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.t2b.api.persistence.common.Messages;
import com.t2b.api.persistence.entity.Member;
import com.t2b.api.persistence.error.Errors;
import com.t2b.api.persistence.error.T2BApiException;
import com.t2b.api.persistence.repository.MemberRepository;
import com.t2b.entity.MemberDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@RestController
@Slf4j
public class MemberController {

   @Autowired
   private ModelMapper      mapper;

   @Autowired
   private MemberRepository memberRepo;

   @PostMapping(path = "/member")
   public MemberDTO createMember(@Valid @RequestBody MemberDTO memberDto) {
      log.info(logMsg(Messages.CREATING_MEMBER, memberDto));
      Member entityToBeSaved = convertToEntity(memberDto);
      MemberDTO resultDto = convertToDTO(memberRepo.save(entityToBeSaved));
      log.info(logMsg(Messages.CREATED_MEMBER_SUCCESSFULLY, resultDto));
      return resultDto;
   }

   @DeleteMapping(path = "/member/{memberId}")
   public ResponseEntity<Object> deleteMember(@PathVariable Long memberId) {
      log.info(logMsg(Messages.DELETING_MEMBER, memberId));
      return memberRepo.findById(memberId).map(member -> {
         memberRepo.delete(member);
         log.info(logMsg(Messages.DELETED_MEMBER_SUCCESSFULLY, memberId));
         return ResponseEntity.ok().build();
      }).orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                               errMsg(Errors.MEMBER_DOESNOT_EXIST, memberId)));
   }

   @GetMapping(path = "/member/{memberId}")
   public MemberDTO findMember(@PathVariable Long memberId) {
      log.info(logMsg(Messages.FINDING_MEMBER_BY_ID, memberId));
      MemberDTO foundDto = memberRepo.findById(memberId)
         .map(this::convertToDTO)
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.MEMBER_DOESNOT_EXIST,
                                                       memberId)));
      log.info(logMsg(Messages.FOUND_MEMBER, memberId, foundDto));
      return foundDto;
   }

   @GetMapping("/member")
   public Page<MemberDTO> getAll(Pageable pageable) {
      log.info(logMsg(Messages.FINDING_ALL_MEMBERS));
      Page<MemberDTO> pageOfMemberDTOs = null;
      Page<Member> entitiesFound = memberRepo.findAll(pageable);
      if (entitiesFound != null) {
         pageOfMemberDTOs = entitiesFound.map(this::convertToDTO);
      }
      log.info(logMsg(Messages.FOUND_MEMBERS,
                      (pageOfMemberDTOs != null ? pageOfMemberDTOs.getNumberOfElements()
                                                : 0)));
      return pageOfMemberDTOs;
   }

   @PutMapping(path = "/member/{memberId}")
   public MemberDTO updateMember(@PathVariable Long memberId,
                                 @RequestBody MemberDTO memberDto) {
      log.info(logMsg(Messages.UPDATING_MEMBER, memberId, memberDto));
      Member modifiedEntity = memberRepo.findById(memberId).map(member -> {
         member.setFirstName(memberDto.getFirstName());
         member.setLastName(memberDto.getLastName());
         member.setGender(memberDto.getGender());
         member.setEmailAddress(memberDto.getEmailAddress());
         member.setPhoneNumber(memberDto.getPhoneNumber());
         member.setAddressLine1(memberDto.getAddressLine1());
         member.setAddressLine2(memberDto.getAddressLine2());
         member.setCity(memberDto.getCity());
         member.setState(memberDto.getState());
         member.setZipCode(memberDto.getZipCode());
         member.setCancel(memberDto.isCancel());
         return member;
      }).orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                               errMsg(Errors.MEMBER_DOESNOT_EXIST, memberId)));
      MemberDTO updatedDto = convertToDTO(memberRepo.save(modifiedEntity));
      log.info(logMsg(Messages.UPDATED_MEMBER_SUCCESSFULLY, updatedDto));
      return updatedDto;
   }

   private MemberDTO convertToDTO(@Valid Member member) {
      return mapper.map(member, MemberDTO.class);
   }

   /**
    * @param memberDto
    * @return
    */
   private Member convertToEntity(@Valid MemberDTO memberDto) {
      return mapper.map(memberDto, Member.class);
   }
}
