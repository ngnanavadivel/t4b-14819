package com.t2b.api.persistence.repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.t2b.api.persistence.entity.Code;
import com.t2b.api.persistence.entity.Member;

/**
 * @author Hukmchand
 *
 */
@Repository
public interface CodeRepository extends PagingAndSortingRepository<Code, Long> {
   List<Code> findByCodeTypeName (String codeTypeName);
}
