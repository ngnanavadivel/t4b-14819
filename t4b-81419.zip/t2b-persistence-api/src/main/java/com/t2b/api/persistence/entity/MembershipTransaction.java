package com.t2b.api.persistence.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
@EqualsAndHashCode(callSuper=true)
@Entity
public class MembershipTransaction extends AuditableEntity {

   private static final long serialVersionUID = 1L;

   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   private Long              id;
   
   @NotNull
   @Column
   private String transactionTypeCode;
   
   @NotNull
   @Column
   private LocalDateTime transactionDate;

   @NotNull
   @Column
   private Long memberId;
   
   @NotNull
   @Column
   private Long membershipPlanId;
   
   @NotNull
   @Column
   private BigDecimal transactionAmount;
   
   @NotNull
   @Column
   private String transactionCurrency;
   
   @NotNull
   @Column
   private String transactionStatus;
}
