package com.t2b.api.persistence.cfg;

import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Configuration
public class AppConfig {

   @Bean
   public WebMvcConfigurer corsConfigurer() {
      return new WebMvcConfigurer() {

         @Override
         public void addCorsMappings(CorsRegistry registry) {
            // TODO Later restrict the * with ticket2beauty.com once domain linking with AWS
            // is done!
            registry.addMapping("/*").allowedOrigins("*");
         }
      };
   }

   @Bean
   public ModelMapper mapper() {
      return new ModelMapper();
   }
}
