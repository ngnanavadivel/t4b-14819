package com.t2b.api.persistence.error;

/**
 * @author Nataraj Gnanavadivel
 *
 */
public enum Errors {
      MEMBER_DOESNOT_EXIST("Member with ID %d doesn't exist."),
      MEMBERSHIP_DOESNOT_EXIST("MemberShip with ID %d doesn't exist."),
      MEMBERSHIP_PLAN_DOESNOT_EXIST("MemberShipPlan with ID %d doesn't exist."), 
      MEMBERSHIP_TRANSACTION_NOT_FOUND("Membership Transaction with ID %d doesn't exist."),
      PROVIDER_DOESNOT_EXIST("PROVIDER with ID %d doesn't exist."),
      PROVIDER_CONTACT_DOESNOT_EXIST("PROVIDER CONTACT with ID %d doesn't exist."),
      PROVIDER_SERVICE_DOESNOT_EXIST("PROVIDER CONTACT with ID %d doesn't exist."),
      CODE_DOESNOT_EXIST("Code with ID %d doesn't exist."),
      CODE_TYPE_DOESNOT_EXIST("CodeType with ID %d doesn't exist.");
      

   private String message;

   Errors(String message) {
      this.message = message;
   }

   public String value() {
      return this.message;
   }
}
