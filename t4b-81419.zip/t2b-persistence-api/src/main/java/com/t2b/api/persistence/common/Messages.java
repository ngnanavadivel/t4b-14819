package com.t2b.api.persistence.common;

/**
 * @author Nataraj Gnanavadivel
 *
 */
public enum Messages {
      /* Member */
      CREATING_MEMBER("Creating Member with values %s"),
      UPDATING_MEMBER("Updating Member with values %s"),
      DELETING_MEMBER("Deleting Member with ID %d"),
      FINDING_MEMBER_BY_ID("Selecting Member with ID %d"),
      CREATED_MEMBER_SUCCESSFULLY("Member created successfully with values %s"),
      UPDATED_MEMBER_SUCCESSFULLY("Member updated successfully with values %s"),
      DELETED_MEMBER_SUCCESSFULLY("Member deleted successfully with ID %d"),
      FOUND_MEMBER("Member found with ID %d with values %s"),
      FINDING_ALL_MEMBERS("Finding all Members"),
      FOUND_MEMBERS("%d Members has been found."),
      /* Membership */
      CREATING_MEMBERSHIP_WITH_PLAN_ID("Creating Membership for member with ID %d against MembershipPlan ID %d"),
      UPDATING_MEMBERSHIP("Updating Membership for member with ID %d with values %s"),
      DELETING_MEMBERSHIP("Deleting Membership with ID %d for member with ID %d"),
      FINDING_MEMBERSHIP_BY_ID("Selecting Membership with ID %d for member with ID %d"),
      CREATED_MEMBERSHIP_SUCCESSFULLY("Membership created successfully for member with ID %d with values %s"),
      UPDATED_MEMBERSHIP_SUCCESSFULLY("Membership updated successfully for member with ID %d with values %s"),
      DELETED_MEMBERSHIP_SUCCESSFULLY("Membership deleted successfully with ID %d for member with ID %d"),
      FOUND_MEMBERSHIP("Membership found with ID %d with values %s"),
      FINDING_ALL_MEMBERSHIP("Finding all Memberships for member with ID %d"),
      FOUND_MEMBERSHIPS("%d Memberships has been found for member with ID %d"),
      /* MembershipPlan */
      CREATING_MEMBERSHIP_PLAN("Creating MembershipPlan with values %s"),
      UPDATING_MEMBERSHIP_PLAN("Updating MembershipPlan with values %s"),
      FINDING_MEMBERSHIP_PLAN_BY_ID("Selecting MembershipPlan with ID %d"),
      CREATED_MEMBERSHIP_PLAN_SUCCESSFULLY("MembershipPlan created successfully with values %s"),
      DELETING_MEMBERSHIP_PLAN("Deleting MembershipPlan with ID %d"),
      UPDATED_MEMBERSHIP_PLAN_SUCCESSFULLY("MembershipPlan updated successfully with values %s"),
      DELETED_MEMBERSHIP_PLAN_SUCCESSFULLY("MembershipPlan deleted successfully with ID %d"),
      FOUND_MEMBERBERSHIP_PLAN("MembershipPlan found with ID %d with values %s"),
      FINDING_ALL_MEMBERSHIP_PLANS("Finding all MembershipPlans"),
      FOUND_MEMBERSHIP_PLANS("%d MembershipPlans has been found."),
      /* Membership Transaction */
      CREATING_MEMBERSHIP_TRANSACTION("Creating Membership Transaction with values %s"),
      CREATED_MEMBERSHIP_TRANSACTION_SUCCESSFULLY("Membership Transaction created successfully with values %s"),
      FINDING_ALL_TRANSACTIONS_BY_MEMBER_ID("Finding all Membership transactions for member with ID %d"),
      FOUND_ALL_MEMBERSHIP_TRANSACTIONS("%d Membership Transactions has been found."),
      UPDATING_MEMBERSHIP_TXN_STATUS("Updating Status of Membership Transaction with ID %d to %s"),
      UPDATED_MEMBERSHIP_TRANSACTION_SUCCESSFULLY("Updated Status of Membership Transaction with ID %d successfully to %s"),
      /* Provider */
      CREATING_PROVIDER("Creating Provider with values %s"),
      UPDATING_PROVIDER("Updating Provider with values %s"),
      DELETING_PROVIDER("Deleting Provider with ID %d"),
      FINDING_PROVIDER_BY_ID("Selecting Provider with ID %d"),
      CREATED_PROVIDER_SUCCESSFULLY("Provider created successfully with values %s"),
      UPDATED_PROVIDER_SUCCESSFULLY("Provider updated successfully with values %s"),
      DELETED_PROVIDER_SUCCESSFULLY("Provider deleted successfully with ID %d"),
      FOUND_PROVIDER("Provider found with ID %d with values %s"),
      FINDING_ALL_PROVIDERS("Finding all Providers"),
      FOUND_PROVIDERS("%d Providers has been found."),
      /* Provider Contact */
      CREATING_PROVIDER_CONTACT("Creating Provider Contact with values %s"),
      UPDATING_PROVIDER_CONTACT("Updating Provider Contact with values %s"),
      DELETING_PROVIDER_CONTACT("Deleting Provider Contact with ID %d"),
      FINDING_PROVIDER_CONTACT_BY_ID("Selecting Provider Contact with ID %d"),
      CREATED_PROVIDER_CONTACT_SUCCESSFULLY("Provider Contact created successfully with values %s"),
      UPDATED_PROVIDER_CONTACT_SUCCESSFULLY("Provider Contact updated successfully with values %s"),
      DELETED_PROVIDER_CONTACT_SUCCESSFULLY("Provider Contact deleted successfully with ID %d"),
      FOUND_PROVIDER_CONTACT("Provider Contact found with ID %d with values %s"),
      FINDING_ALL_PROVIDER_CONTACTS("Finding all Provider Contacts"),
      FOUND_PROVIDER_CONTACTS("%d Provider Contacts has been found."),
      /* Provider Service */
      CREATING_PROVIDER_SERVICE("Creating Provider Service with values %s"),
      UPDATING_PROVIDER_SERVICE("Updating Provider Service with values %s"),
      DELETING_PROVIDER_SERVICE("Deleting Provider Service with ID %d"),
      FINDING_PROVIDER_SERVICE_BY_ID("Selecting Provider Service with ID %d"),
      CREATED_PROVIDER_SERVICE_SUCCESSFULLY("Provider Service created successfully with values %s"),
      UPDATED_PROVIDER_SERVICE_SUCCESSFULLY("Provider Service updated successfully with values %s"),
      DELETED_PROVIDER_SERVICE_SUCCESSFULLY("Provider Service deleted successfully with ID %d"),
      FOUND_PROVIDER_SERVICE("Provider Service found with ID %d with values %s"),
      FINDING_ALL_PROVIDER_SERVICES("Finding all Provider Services"),
      FOUND_PROVIDER_SERVICES("%d Provider Services has been found."),
      /* Code */
      CREATING_CODE("Creating Code with values %s"),
      FINDING_ALL_CODES("Finding all Codes"),
      CREATED_CODE_SUCCESSFULLY("Code created successfully for code with ID %d with values %s"),;

   private String message;

   Messages(String message) {
      this.message = message;
   }

   public String value() {
      return this.message;
   }
}
