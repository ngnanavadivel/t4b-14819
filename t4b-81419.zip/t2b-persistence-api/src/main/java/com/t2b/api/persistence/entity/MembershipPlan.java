package com.t2b.api.persistence.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
public class MembershipPlan extends AuditableEntity {

   private static final long serialVersionUID = 3013996932401904612L;

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long              membershipPlanId;

   @NotNull
   private String            planName;

   @NotNull
   @Lob
   private String            planDescription;

   @NotNull
   private Double            planAmount;

   @NotNull
   private Integer           durationInMonths;
}
