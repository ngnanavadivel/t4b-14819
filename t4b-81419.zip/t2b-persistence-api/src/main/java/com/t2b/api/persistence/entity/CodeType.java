package com.t2b.api.persistence.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
public class CodeType extends AuditableEntity {

   private static final long serialVersionUID = 2716356425907074927L;

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long              id;

   @Column
   private String            name;

   @Column
   private String            description;

   @Column
   private boolean           isCancel;

}
