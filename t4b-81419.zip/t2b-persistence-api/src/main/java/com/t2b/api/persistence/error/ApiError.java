package com.t2b.api.persistence.error;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Data
public class ApiError {

   private HttpStatus    status;

   @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy hh:mm:ss")
   private LocalDateTime timestamp = LocalDateTime.now();

   private String        message;

   private String        debugMessage;

   public ApiError(HttpStatus status, String message) {
      this.status = status;
      this.message = message;
   }

   public ApiError(HttpStatus status, String message, Throwable t) {
      this.status = status;
      this.message = message;
      this.debugMessage = t != null ? t.getMessage() : "";
   }

}
