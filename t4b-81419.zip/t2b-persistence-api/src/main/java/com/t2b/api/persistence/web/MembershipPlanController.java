package com.t2b.api.persistence.web;

import static com.t2b.api.persistence.common.LogMessageBuilder.logMsg;
import static com.t2b.api.persistence.error.ErrorMesssageBuilder.errMsg;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.t2b.api.persistence.common.Messages;
import com.t2b.api.persistence.entity.MembershipPlan;
import com.t2b.api.persistence.error.Errors;
import com.t2b.api.persistence.error.T2BApiException;
import com.t2b.api.persistence.repository.MembershipPlanRepository;
import com.t2b.api.persistence.repository.MembershipRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@RestController
@Slf4j
public class MembershipPlanController {

   @Autowired
   private MembershipRepository     membershipRepo;

   @Autowired
   private MembershipPlanRepository membershipPlanRepo;

   @PostMapping(path = "/membershipPlan")
   public MembershipPlan
          createMembershipPlan(@Valid @RequestBody MembershipPlan membershipPlan) {
      log.info(logMsg(Messages.CREATING_MEMBERSHIP_PLAN, membershipPlan));
      MembershipPlan savedPlan = membershipPlanRepo.save(membershipPlan);
      log.info(logMsg(Messages.CREATED_MEMBERSHIP_PLAN_SUCCESSFULLY, savedPlan));
      return savedPlan;
   }

   @DeleteMapping(path = "/membershipPlan/{membershipPlanId}")
   public ResponseEntity<Object> deleteMembershipPlan(@PathVariable Long membershipPlanId) {
      log.info(logMsg(Messages.DELETING_MEMBERSHIP_PLAN, membershipPlanId));
      return membershipPlanRepo.findById(membershipPlanId).map(membershipPlan -> {
         membershipPlanRepo.delete(membershipPlan);
         log.info(logMsg(Messages.DELETED_MEMBERSHIP_PLAN_SUCCESSFULLY, membershipPlanId));
         return ResponseEntity.ok().build();
      })
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.MEMBERSHIP_PLAN_DOESNOT_EXIST,
                                                       membershipPlanId)));
   }

   @GetMapping(path = "/membershipPlan/{membershipPlanId}")
   public MembershipPlan findMembershipPlan(@PathVariable Long membershipPlanId) {
      log.info(logMsg(Messages.FINDING_MEMBERSHIP_PLAN_BY_ID, membershipPlanId));
      MembershipPlan foundPlan = membershipPlanRepo.findById(membershipPlanId)
         .map(membershipPlan -> membershipPlan)
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.MEMBERSHIP_PLAN_DOESNOT_EXIST,
                                                       membershipPlanId)));
      log.info(logMsg(Messages.FOUND_MEMBERBERSHIP_PLAN, foundPlan));
      return foundPlan;
   }

   @GetMapping("/membershipPlan")
   public List<MembershipPlan> getAll() {
      log.info(logMsg(Messages.FINDING_ALL_MEMBERSHIP_PLANS));
      List<MembershipPlan> findAll = membershipPlanRepo.findAll();
      log.info(logMsg(Messages.FOUND_MEMBERSHIP_PLANS, findAll != null ? findAll.size() : 0));
      return findAll;
   }

   @PutMapping(path = "/membershipPlan/{membershipPlanId}")
   public MembershipPlan
          updateMembershipPlan(@PathVariable Long membershipPlanId,
                               @Valid @RequestBody MembershipPlan membershipPlanRequest) {
      log.info(logMsg(Messages.UPDATING_MEMBERSHIP_PLAN, membershipPlanId));
      MembershipPlan updatedPlan = membershipPlanRepo.findById(membershipPlanId)
         .map(membershipPlan -> {
            membershipPlan.setPlanName(membershipPlanRequest.getPlanName());
            membershipPlan.setPlanDescription(membershipPlanRequest.getPlanDescription());
            return membershipPlanRepo.save(membershipPlan);
         })
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.MEMBERSHIP_PLAN_DOESNOT_EXIST,
                                                       membershipPlanId)));
      log.info(logMsg(Messages.UPDATED_MEMBERSHIP_PLAN_SUCCESSFULLY, updatedPlan));
      return updatedPlan;
   }
}
