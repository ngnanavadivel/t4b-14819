package com.t2b.api.persistence.repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.t2b.api.persistence.entity.Member;
import com.t2b.api.persistence.entity.ProviderContact;
import com.t2b.api.persistence.entity.ProviderService;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Repository
public interface ProviderServiceRepository extends PagingAndSortingRepository<ProviderService, Long> {
   List<ProviderService> findAllByProviderId(Long providerId);
}
