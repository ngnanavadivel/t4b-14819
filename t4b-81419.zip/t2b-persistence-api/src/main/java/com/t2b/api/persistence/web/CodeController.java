package com.t2b.api.persistence.web;

import static com.t2b.api.persistence.common.LogMessageBuilder.logMsg;
import static com.t2b.api.persistence.error.ErrorMesssageBuilder.errMsg;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.t2b.api.persistence.common.Messages;
import com.t2b.api.persistence.entity.Code;
import com.t2b.api.persistence.entity.CodeType;
import com.t2b.api.persistence.entity.Member;
import com.t2b.api.persistence.error.Errors;
import com.t2b.api.persistence.error.T2BApiException;
import com.t2b.api.persistence.repository.CodeRepository;
import com.t2b.api.persistence.repository.CodeTypeRepository;
import com.t2b.api.persistence.repository.MemberRepository;
import com.t2b.entity.CodeDTO;
import com.t2b.entity.CodeTypeDTO;
import com.t2b.entity.MemberDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@RestController
@Slf4j
public class CodeController {

   @Autowired
   private ModelMapper      mapper;

   @Autowired
   private CodeRepository codeRepo;
   
   @Autowired
   private CodeTypeRepository codeTypeRepo;
   
   
   @PostMapping(path = "/code")
   public CodeDTO createCode(@Valid @RequestBody CodeDTO codeDto) {
      log.info(logMsg(Messages.CREATING_CODE, codeDto));
      Code entityToBeSaved = convertToEntity(codeDto);
      
      Optional<CodeType> code = codeTypeRepo.findById(codeDto.getCodeTypeId());
      if (code.isPresent()) {
         entityToBeSaved.setCodeType(code.get());
       
      }
      else {
         throw new T2BApiException(HttpStatus.NOT_FOUND,
                                   errMsg(Errors.CODE_TYPE_DOESNOT_EXIST, codeDto.getCodeTypeId()));
      }
      
      
      CodeDTO resultDto = convertToDTO(codeRepo.save(entityToBeSaved));
      log.info(logMsg(Messages.CREATED_CODE_SUCCESSFULLY, resultDto));
      return resultDto;
   }
   
   
   @PostMapping(path = "/codeType")
   public CodeTypeDTO createCodeType(@Valid @RequestBody CodeTypeDTO codeDto) {
      log.info(logMsg(Messages.CREATING_CODE, codeDto));
      CodeType entityToBeSaved = convertToCodeTypeEntity(codeDto);
      CodeTypeDTO resultDto = convertToCodeTypeDTO(codeTypeRepo.save(entityToBeSaved));
      log.info(logMsg(Messages.CREATED_CODE_SUCCESSFULLY, resultDto));
      return resultDto;
   }

   
   @GetMapping("/code/{codeType}")
   public List<CodeDTO> getAllByCodeType(String codeType) {
      log.info(logMsg(Messages.FINDING_ALL_CODES));
      List<CodeDTO> pageOfCodeDTOs = new ArrayList<CodeDTO>();
      List<Code> entitiesFound = codeRepo.findByCodeTypeName(codeType);
      if (entitiesFound != null) {
         for(Code code:entitiesFound)
         {
         pageOfCodeDTOs.add(convertToDTO(code));
         }
      }
      log.info(logMsg(Messages.FOUND_MEMBERS,
                      (pageOfCodeDTOs != null ? pageOfCodeDTOs.size()
                                                : 0)));
      return pageOfCodeDTOs;
   }
   
   

   

   private CodeDTO convertToDTO(@Valid Code code) {
      return mapper.map(code, CodeDTO.class);
   }

   /**
    * @param codeDto
    * @return
    */
   private Code convertToEntity(@Valid CodeDTO codeDto) {
      return mapper.map(codeDto, Code.class);
   }
   
   private CodeTypeDTO convertToCodeTypeDTO(@Valid CodeType code) {
      return mapper.map(code, CodeTypeDTO.class);
   }

   /**
    * @param codeDto
    * @return
    */
   private CodeType convertToCodeTypeEntity(@Valid CodeTypeDTO codeDto) {
      return mapper.map(codeDto, CodeType.class);
   }
}
