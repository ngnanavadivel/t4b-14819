package com.t2b.api.persistence.web;

import static com.t2b.api.persistence.common.LogMessageBuilder.logMsg;
import static com.t2b.api.persistence.error.ErrorMesssageBuilder.errMsg;

import java.time.LocalDateTime;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.t2b.api.persistence.common.Messages;
import com.t2b.api.persistence.entity.Membership;
import com.t2b.api.persistence.entity.MembershipPlan;
import com.t2b.api.persistence.error.Errors;
import com.t2b.api.persistence.error.T2BApiException;
import com.t2b.api.persistence.repository.MemberRepository;
import com.t2b.api.persistence.repository.MembershipPlanRepository;
import com.t2b.api.persistence.repository.MembershipRepository;
import com.t2b.entity.MembershipDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Slf4j
@RestController
public class MembershipController {

   @Autowired
   private MemberRepository         memberRepo;

   @Autowired
   private MembershipRepository     membershipRepo;

   @Autowired
   private MembershipPlanRepository membershipPlanRepo;

   @PostMapping(path = "/member/{memberId}/membership/plan/{planId}")
   public MembershipDTO createMembership(@PathVariable Long memberId,
                                         @PathVariable Long planId) {
      log.info(logMsg(Messages.CREATING_MEMBERSHIP_WITH_PLAN_ID, memberId, planId));

      Membership newMembership = new Membership();
      newMembership.setCancelled(false);
      // Make Today the membership's start date.
      newMembership.setStartDate(LocalDateTime.now());
      Optional<MembershipPlan> membershipPlan = membershipPlanRepo.findById(planId);
      if (membershipPlan.isPresent()) {
         newMembership.setMembershipPlan(membershipPlan.get());
         // Update membership end date based on plan duration.
         newMembership.setEndDate(LocalDateTime.now()
            .plusMonths(membershipPlan.get().getDurationInMonths()));
      }
      else {
         throw new T2BApiException(HttpStatus.NOT_FOUND,
                                   errMsg(Errors.MEMBERSHIP_PLAN_DOESNOT_EXIST, planId));
      }
      Membership savedMembership = memberRepo.findById(memberId).map(member -> {
         newMembership.setMember(member);
         return membershipRepo.save(newMembership);
      }).orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                               errMsg(Errors.MEMBER_DOESNOT_EXIST, memberId)));
      log.info(logMsg(Messages.CREATED_MEMBERSHIP_SUCCESSFULLY, memberId, savedMembership));
      MembershipDTO response = new MembershipDTO();
      response.setCancelled(savedMembership.isCancelled());
      response.setId(savedMembership.getId());
      response.setMemberId(savedMembership.getMember().getId());
      response.setMembershipPlanId(savedMembership.getMembershipPlan().getMembershipPlanId());
      response.setStartDate(savedMembership.getStartDate());
      response.setEndDate(savedMembership.getEndDate());
      return response;
   }

   @DeleteMapping(path = "/member/{memberId}/membership/{membershipId}")
   public ResponseEntity<Object> deleteMembership(@PathVariable Long memberId,
                                                  @PathVariable Long membershipId) {
      log.info(logMsg(Messages.DELETING_MEMBERSHIP, membershipId, memberId));
      if (!memberRepo.existsById(memberId)) {
         throw new T2BApiException(HttpStatus.NOT_FOUND,
                                   errMsg(Errors.MEMBER_DOESNOT_EXIST, memberId));
      }
      return membershipRepo.findById(membershipId).map(membership -> {
         membershipRepo.delete(membership);
         log.info(logMsg(Messages.DELETED_MEMBERSHIP_SUCCESSFULLY, membershipId, memberId));
         return ResponseEntity.ok().build();
      })
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.MEMBERSHIP_DOESNOT_EXIST,
                                                       membershipId)));
   }

   @GetMapping(path = "/member/{memberId}/membership/{membershipId}")
   public Membership findMembership(@PathVariable Long memberId,
                                    @PathVariable Long membershipId) {
      log.info(logMsg(Messages.FINDING_MEMBERSHIP_BY_ID, membershipId, memberId));
      if (!memberRepo.existsById(memberId)) {
         throw new T2BApiException(HttpStatus.NOT_FOUND,
                                   errMsg(Errors.MEMBER_DOESNOT_EXIST, memberId));
      }
      Membership foundMembership = membershipRepo.findById(membershipId)
         .map(membership -> membership)
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.MEMBERSHIP_DOESNOT_EXIST,
                                                       membershipId)));
      log.info(logMsg(Messages.FOUND_MEMBERSHIP, membershipId, foundMembership));
      return foundMembership;
   }

   @GetMapping("/member/{memberId}/membership")
   public Page<Membership> getAllByMemberId(@PathVariable Long memberId, Pageable pageable) {
      log.info(logMsg(Messages.FINDING_ALL_MEMBERSHIP, memberId));
      Page<Membership> foundMemberships = membershipRepo.findAllByMemberId(memberId, pageable);
      log.info(logMsg(Messages.FOUND_MEMBERSHIPS,
                      (foundMemberships != null ? foundMemberships.getNumberOfElements() : 0),
                      memberId));
      return foundMemberships;
   }

   @PutMapping(path = "/member/{memberId}/membership/{membershipId}")
   public Membership updateMembership(@PathVariable Long memberId,
                                      @PathVariable Long membershipId,
                                      @Valid @RequestBody Membership membershipRequest) {
      log.info(logMsg(Messages.UPDATING_MEMBERSHIP, memberId, membershipRequest));
      if (!memberRepo.existsById(memberId)) {
         throw new T2BApiException(HttpStatus.NOT_FOUND,
                                   errMsg(Errors.MEMBER_DOESNOT_EXIST, memberId));
      }
      Membership updatedMembership = membershipRepo.findById(membershipId).map(membership -> {
         membership.setStartDate(membershipRequest.getStartDate());
         membership.setEndDate(membershipRequest.getEndDate());
         membership.setCancelled(membershipRequest.isCancelled());
         return membershipRepo.save(membership);
      })
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.MEMBERSHIP_DOESNOT_EXIST,
                                                       membershipId)));
      log.info(logMsg(Messages.UPDATED_MEMBERSHIP_SUCCESSFULLY, memberId, updatedMembership));
      return updatedMembership;
   }
}
