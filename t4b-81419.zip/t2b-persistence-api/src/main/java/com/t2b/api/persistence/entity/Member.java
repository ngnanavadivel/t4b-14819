package com.t2b.api.persistence.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
public class Member extends AuditableEntity {

   private static final long serialVersionUID = 2716356425907074920L;

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long              id;

   @Column
   private String            firstName;

   @Column
   private String            lastName;

   @Column
   private String            gender;

   @Column
   private String            emailAddress;

   @Column
   private String            addressLine1;

   @Column
   private String            addressLine2;

   @Column
   private String            city;

   @Column
   private String            state;

   @Column
   private String            zipCode;

   @Column
   private String            phoneNumber;

   @Column
   private boolean           isCancel;

}
