package com.t2b.api.persistence.web;

import static com.t2b.api.persistence.common.LogMessageBuilder.logMsg;
import static com.t2b.api.persistence.error.ErrorMesssageBuilder.errMsg;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.t2b.api.persistence.common.Messages;
import com.t2b.api.persistence.entity.MembershipTransaction;
import com.t2b.api.persistence.error.Errors;
import com.t2b.api.persistence.error.T2BApiException;
import com.t2b.api.persistence.repository.MembershipTransactionRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@Slf4j
@RestController
public class MembershipTransactionController {

   @Autowired
   private MembershipTransactionRepository transactionRepo;

   @PostMapping("/transaction")
   public MembershipTransaction createTxn(@RequestBody MembershipTransaction txn) {
      log.info(logMsg(Messages.CREATING_MEMBERSHIP_TRANSACTION, txn));
      MembershipTransaction savedTxn = transactionRepo.save(txn);
      log.info(logMsg(Messages.CREATED_MEMBERSHIP_TRANSACTION_SUCCESSFULLY, savedTxn));
      return savedTxn;
   }

   @GetMapping("/member/{memberId}/transaction")
   public Page<MembershipTransaction> getAll(@PathVariable Long memberId, Pageable pageable) {
      log.info(logMsg(Messages.FINDING_ALL_TRANSACTIONS_BY_MEMBER_ID, memberId));
      Page<MembershipTransaction> pageOfAllTxns = transactionRepo.findAllByMemberId(memberId,
                                                                                    pageable);
      log.info(logMsg(Messages.FOUND_ALL_MEMBERSHIP_TRANSACTIONS,
                      pageOfAllTxns != null ? pageOfAllTxns.getNumberOfElements() : 0));
      return pageOfAllTxns;
   }

   @PostMapping("/transaction/{txnId}/{transactionStatus}")
   public MembershipTransaction updateTxnStatus(@PathVariable Long txnId,
                                                @PathVariable String transactionStatus) {
      log.info(logMsg(Messages.UPDATING_MEMBERSHIP_TXN_STATUS, txnId, transactionStatus));
      Optional<MembershipTransaction> findById = transactionRepo.findById(txnId);
      if (findById.isPresent()) {
         MembershipTransaction txnFound = findById.get();
         txnFound.setTransactionStatus(transactionStatus);
         MembershipTransaction updatedTxn = transactionRepo.save(txnFound);
         log.info(logMsg(Messages.UPDATED_MEMBERSHIP_TRANSACTION_SUCCESSFULLY,
                         txnId,
                         transactionStatus));
         return updatedTxn;
      }
      else {
         throw new T2BApiException(HttpStatus.NOT_FOUND,
                                   errMsg(Errors.MEMBERSHIP_TRANSACTION_NOT_FOUND, txnId));
      }
   }
}
