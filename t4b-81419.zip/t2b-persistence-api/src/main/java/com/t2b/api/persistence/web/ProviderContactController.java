package com.t2b.api.persistence.web;

import static com.t2b.api.persistence.common.LogMessageBuilder.logMsg;
import static com.t2b.api.persistence.error.ErrorMesssageBuilder.errMsg;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.t2b.api.persistence.common.Messages;
import com.t2b.api.persistence.entity.Code;
import com.t2b.api.persistence.entity.MembershipPlan;
import com.t2b.api.persistence.entity.Provider;
import com.t2b.api.persistence.entity.ProviderContact;
import com.t2b.api.persistence.error.Errors;
import com.t2b.api.persistence.error.T2BApiException;
import com.t2b.api.persistence.repository.CodeRepository;
import com.t2b.api.persistence.repository.ProviderContactRepository;
import com.t2b.api.persistence.repository.ProviderRepository;
import com.t2b.entity.ProviderContactDTO;
import com.t2b.entity.ProviderDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Hukmchand
 *
 */
@RestController
@Slf4j
public class ProviderContactController {

   @Autowired
   private ModelMapper      mapper;

   @Autowired
   private ProviderContactRepository providerContactRepo;
   
   @Autowired
   private ProviderRepository providerRepo;
   
   
   @Autowired
   private CodeRepository codeRepo;
   
   PropertyMap<ProviderContactDTO, ProviderContact> skipModifiedFieldsMap = new PropertyMap<ProviderContactDTO, ProviderContact>() {
      protected void configure() {
         skip().setProvider(null);
        }
   };

   @PostMapping(path = "provider/{providerid}/providerContact")
   public ProviderContactDTO createProviderContact(@Valid @PathVariable Long providerid, @RequestBody ProviderContactDTO providerContactDto) {
      log.info(logMsg(Messages.CREATING_PROVIDER_CONTACT, providerContactDto));
      
      mapper.addMappings(skipModifiedFieldsMap);
      
      
      ProviderContact entityToBeSaved = convertToEntity(providerContactDto);
      
      log.info("done to Entity");
      
      Optional<Provider> provider = providerRepo.findById(providerid);
      if (provider.isPresent()) {
       
         entityToBeSaved.setProvider(provider.get());
         log.info("done to Entity 12");
         entityToBeSaved = providerContactRepo.save(entityToBeSaved);
         log.info("done to Entity 13");
         ProviderContactDTO resultDto = convertToDTO(entityToBeSaved);
         log.info("done to Entity 14");
         log.info(logMsg(Messages.CREATED_PROVIDER_CONTACT_SUCCESSFULLY, resultDto));
         return resultDto;
      }
      else {
         throw new T2BApiException(HttpStatus.NOT_FOUND,
                                   errMsg(Errors.PROVIDER_DOESNOT_EXIST, providerid));
      }
      
   }

   @DeleteMapping(path = "/provider/providerContact/{providerContactId}")
   public ResponseEntity<Object> deleteProviderContact(@PathVariable Long providerContactId) {
      log.info(logMsg(Messages.DELETING_PROVIDER_CONTACT, providerContactId));
      return providerContactRepo.findById(providerContactId).map(providerContact -> {
         providerContactRepo.delete(providerContact);
         log.info(logMsg(Messages.DELETED_PROVIDER_CONTACT_SUCCESSFULLY, providerContactId));
         return ResponseEntity.ok().build();
      }).orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                               errMsg(Errors.PROVIDER_CONTACT_DOESNOT_EXIST, providerContactId)));
   }

   @GetMapping(path = "/provider/providerContact/{providerContactId}")
   public ProviderContactDTO findProviderContact(@PathVariable Long providerContactId) {
      log.info(logMsg(Messages.FINDING_PROVIDER_CONTACT_BY_ID, providerContactId));
      ProviderContactDTO foundDto = providerContactRepo.findById(providerContactId)
         .map(this::convertToDTO)
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.PROVIDER_CONTACT_DOESNOT_EXIST,
                                                       providerContactId)));
      log.info(logMsg(Messages.FOUND_PROVIDER_CONTACT, providerContactId, foundDto));
      return foundDto;
   }

   @GetMapping("/provider/{providerid}/providerContact")
   public List<ProviderContactDTO> getAll(@PathVariable Long providerid,Pageable pageable) {
      log.info(logMsg(Messages.FINDING_ALL_PROVIDER_CONTACTS));
      List<ProviderContactDTO> pageOfProviderContactDTOs =  new ArrayList<ProviderContactDTO>();
      List<ProviderContact> entitiesFound = providerContactRepo.findAllByProviderId(providerid); 
      if (entitiesFound != null) {
         for(ProviderContact entity:entitiesFound)
         {
         pageOfProviderContactDTOs.add(convertToDTO(entity));
         }
      }
      log.info(logMsg(Messages.FOUND_PROVIDER_CONTACTS,
                      (pageOfProviderContactDTOs != null ? pageOfProviderContactDTOs.size()
                                                : 0)));
      return pageOfProviderContactDTOs;
   }

  

   private ProviderContactDTO convertToDTO(@Valid ProviderContact providerContact) {
      return mapper.map(providerContact, ProviderContactDTO.class);
   }

   /**
    * @param providerContactDto
    * @return
    */
   private ProviderContact convertToEntity(@Valid ProviderContactDTO providerContactDto) {
      return mapper.map(providerContactDto, ProviderContact.class);
   }
}
