package com.t2b.api.persistence.error;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * @author Nataraj Gnanavadivel
 *
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ErrorMesssageBuilder {

   public static String errMsg(Errors errorMessage, Object... args) {
      return String.format(errorMessage.value(), args);
   }
}
