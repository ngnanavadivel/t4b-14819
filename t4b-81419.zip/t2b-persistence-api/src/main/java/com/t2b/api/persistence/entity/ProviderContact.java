package com.t2b.api.persistence.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
public class ProviderContact extends AuditableEntity {

   private static final long serialVersionUID = 2716356425907074921L;

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long              id;

   @Column
   private String            firstName;

   @Column
   private String            lastName;

   @Column
   private String            contactTitle;
   
   @Column
   private boolean           isPrimary;

   @Column
   private String            emailAddress;

   @Column
   private String            phoneNumber;

   @Column
   private boolean           isCancel;
   
   @ManyToOne(fetch = FetchType.LAZY, optional = false)
   @JoinColumn(name = "provider_id", nullable = false)
   @OnDelete(action = OnDeleteAction.CASCADE)
   private Provider            provider;

}
