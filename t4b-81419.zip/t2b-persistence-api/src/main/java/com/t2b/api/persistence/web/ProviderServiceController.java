package com.t2b.api.persistence.web;

import static com.t2b.api.persistence.common.LogMessageBuilder.logMsg;
import static com.t2b.api.persistence.error.ErrorMesssageBuilder.errMsg;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.t2b.api.persistence.common.Messages;
import com.t2b.api.persistence.entity.Code;
import com.t2b.api.persistence.entity.MembershipPlan;
import com.t2b.api.persistence.entity.Provider;
import com.t2b.api.persistence.entity.ProviderService;
import com.t2b.api.persistence.error.Errors;
import com.t2b.api.persistence.error.T2BApiException;
import com.t2b.api.persistence.repository.CodeRepository;
import com.t2b.api.persistence.repository.ProviderServiceRepository;
import com.t2b.api.persistence.repository.ProviderRepository;
import com.t2b.api.persistence.repository.ProviderServiceRepository;
import com.t2b.entity.ProviderServiceDTO;
import com.t2b.entity.ProviderDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Hukmchand
 *
 */
@RestController
@Slf4j
public class ProviderServiceController {

   @Autowired
   private ModelMapper      mapper;

   @Autowired
   private ProviderServiceRepository providerServiceRepo;
   
   @Autowired
   private ProviderRepository providerRepo;
   
   
   
   @Autowired
   private CodeRepository codeRepo;
   
   
   @PostMapping(path = "provider/{providerid}/providerService")
   public ProviderServiceDTO createProviderService(@Valid @PathVariable Long providerid, @RequestBody ProviderServiceDTO providerServiceDto) {
      log.info(logMsg(Messages.CREATING_PROVIDER_SERVICE, providerServiceDto));
      
      
      ProviderService entityToBeSaved = convertToEntity(providerServiceDto);
      
     
      
      
      Optional<Code> code = codeRepo.findById(providerServiceDto.getTypeCodeId());
      if (code.isPresent()) {
         entityToBeSaved.setServiceTypeCode(code.get());
      }
      else {
         throw new T2BApiException(HttpStatus.NOT_FOUND,
                                   errMsg(Errors.CODE_DOESNOT_EXIST, providerServiceDto.getTypeCodeId()));
      }
      
      Optional<Provider> provider = providerRepo.findById(providerid);
      if (provider.isPresent()) {
       
         entityToBeSaved.setProvider(provider.get());
        
         entityToBeSaved = providerServiceRepo.save(entityToBeSaved);
       
         ProviderServiceDTO resultDto = convertToDTO(entityToBeSaved);
       
         log.info(logMsg(Messages.CREATED_PROVIDER_SERVICE_SUCCESSFULLY, resultDto));
         return resultDto;
      }
      else {
         throw new T2BApiException(HttpStatus.NOT_FOUND,
                                   errMsg(Errors.PROVIDER_DOESNOT_EXIST, providerid));
      }
      
   }

   @DeleteMapping(path = "/provider/providerService/{providerServiceId}")
   public ResponseEntity<Object> deleteProviderService(@PathVariable Long providerServiceId) {
      log.info(logMsg(Messages.DELETING_PROVIDER_SERVICE, providerServiceId));
      return providerServiceRepo.findById(providerServiceId).map(providerService -> {
         providerServiceRepo.delete(providerService);
         log.info(logMsg(Messages.DELETED_PROVIDER_SERVICE_SUCCESSFULLY, providerServiceId));
         return ResponseEntity.ok().build();
      }).orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                               errMsg(Errors.PROVIDER_SERVICE_DOESNOT_EXIST, providerServiceId)));
   }

   @GetMapping(path = "/provider/providerService/{providerServiceId}")
   public ProviderServiceDTO findProviderService(@PathVariable Long providerServiceId) {
      log.info(logMsg(Messages.FINDING_PROVIDER_SERVICE_BY_ID, providerServiceId));
      ProviderServiceDTO foundDto = providerServiceRepo.findById(providerServiceId)
         .map(this::convertToDTO)
         .orElseThrow(() -> new T2BApiException(HttpStatus.NOT_FOUND,
                                                errMsg(Errors.PROVIDER_SERVICE_DOESNOT_EXIST,
                                                       providerServiceId)));
      log.info(logMsg(Messages.FOUND_PROVIDER_SERVICE, providerServiceId, foundDto));
      return foundDto;
   }

   @GetMapping("/provider/{providerid}/providerService")
   public List<ProviderServiceDTO> getAll(@PathVariable Long providerid,Pageable pageable) {
      log.info(logMsg(Messages.FINDING_ALL_PROVIDER_SERVICES));
      List<ProviderServiceDTO> pageOfProviderServiceDTOs =  new ArrayList<ProviderServiceDTO>();
      List<ProviderService> entitiesFound = providerServiceRepo.findAllByProviderId(providerid); 
      if (entitiesFound != null) {
         for(ProviderService entity:entitiesFound)
         {
         pageOfProviderServiceDTOs.add(convertToDTO(entity));
         }
      }
      log.info(logMsg(Messages.FOUND_PROVIDER_SERVICES,
                      (pageOfProviderServiceDTOs != null ? pageOfProviderServiceDTOs.size()
                                                : 0)));
      return pageOfProviderServiceDTOs;
   }

  

   private ProviderServiceDTO convertToDTO(@Valid ProviderService providerService) {
      return mapper.map(providerService, ProviderServiceDTO.class);
   }

   /**
    * @param providerServiceDto
    * @return
    */
   private ProviderService convertToEntity(@Valid ProviderServiceDTO providerServiceDto) {
      return mapper.map(providerServiceDto, ProviderService.class);
   }
}
