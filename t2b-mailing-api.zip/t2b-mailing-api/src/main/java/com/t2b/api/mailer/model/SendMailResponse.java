package com.t2b.api.mailer.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SendMailResponse {
   private String status;
   private String description;
}
