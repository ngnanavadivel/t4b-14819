package com.t2b.api.mailer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T2bMailingApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(T2bMailingApiApplication.class, args);
	}
}
