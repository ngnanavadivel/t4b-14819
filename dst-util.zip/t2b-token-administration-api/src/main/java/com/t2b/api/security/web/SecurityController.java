package com.t2b.api.security.web;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.t2b.api.security.core.JwtTokenManger;

@RestController
@RequestMapping("/jws/v1")
public class SecurityController {

   @Autowired
   JwtTokenManger tokenManager;

   @PostMapping(path = "/token/{username}")
   public String getToken(@PathVariable String username,
                          @RequestBody Map<String, String> customClaims) throws Exception {
      String jwtId = UUID.randomUUID().toString();
      String issuer = "ticket2beauty.com";
      long expiryInMinutes = 3L;
      return tokenManager
         .generateToken(jwtId, issuer, username, expiryInMinutes, customClaims);
   }

   @PostMapping(path = "/verify")
   public boolean getToken(@RequestParam String jwsToken) throws Exception {
      return tokenManager.verifyToken(jwsToken);
   }

   @PostMapping(path = "/publickey")
   public Map<String, String> getPublicKey() throws Exception {
      Map<String, String> result = new LinkedHashMap<>();
      result.put("KEY_ID", tokenManager.getKeyId());
      result.put("PUBLIC_KEY", tokenManager.getPublicKey());
      return result;
   }
}
