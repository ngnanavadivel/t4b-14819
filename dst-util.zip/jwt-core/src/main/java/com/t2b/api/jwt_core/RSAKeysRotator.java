package com.t2b.api.jwt_core;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class RSAKeysRotator {

   @Autowired
   RSAKeysHolder keysHolder;

   @PostConstruct
   public void init() throws JOSEException {
      log.info("Creating the first pair of RSA keys...");
      this.rotateKeys();
   }

   // Rotate every 2 minutes.
   @Scheduled(cron = "0 0/2 * * * ?")
   public void rotateKeys() throws JOSEException {
      String keyId = "t2b-rsa-"
         + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HHmmss-yyyyMMdd"));
      log.info("Started rotating Keys : "
         + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
         + " with KEY_ID : "
         + keyId);
      RSAKeyGenerator rsaKeyGenerator = new RSAKeyGenerator(2048);
      rsaKeyGenerator.keyID(keyId);
      keysHolder.setRsaJwk(rsaKeyGenerator.generate());
      log.info("Completed rotating Keys : "
         + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
   }
}
