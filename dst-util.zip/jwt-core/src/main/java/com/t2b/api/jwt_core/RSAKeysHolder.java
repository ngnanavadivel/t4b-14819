package com.t2b.api.jwt_core;

import org.springframework.stereotype.Component;

import com.nimbusds.jose.jwk.RSAKey;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@NoArgsConstructor(access=AccessLevel.PRIVATE)
@Data
public class RSAKeysHolder {
   private RSAKey rsaJwk;
}