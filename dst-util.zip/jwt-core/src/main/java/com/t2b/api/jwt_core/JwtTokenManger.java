package com.t2b.api.jwt_core;

import java.sql.Timestamp;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

@Component
public class JwtTokenManger {

   @Autowired
   RSAKeysHolder rsaJwkHolder;

   public String generateToken(String id,
                               String issuer,
                               String subject,
                               long expiryInMinutes,
                               Map<String, String> customClaims) throws Exception {
      RSAKey rsaJwk = rsaJwkHolder.getRsaJwk();
      JWTClaimsSet.Builder builder = new JWTClaimsSet.Builder();
      Timestamp issueTime = Timestamp.valueOf(LocalDateTime.now());
      Timestamp expirationTime = Timestamp
         .valueOf(LocalDateTime.now().plusMinutes(expiryInMinutes));
      builder.jwtID(id)
         .issuer(issuer)
         .subject(subject)
         .expirationTime(expirationTime)
         .issueTime(issueTime)
         .notBeforeTime(issueTime);
      if (customClaims != null && !customClaims.isEmpty()) {
         for (Entry<String, String> e : customClaims.entrySet()) {
            builder.claim(e.getKey(), e.getValue());
         }
      }
      JWTClaimsSet jwtClaimsSet = builder.build();
      JWSSigner signer = new RSASSASigner(rsaJwk);
      SignedJWT signedJWT = new SignedJWT(
                                          new JWSHeader.Builder(JWSAlgorithm.RS256)
                                             .keyID(rsaJwk.getKeyID())
                                             .build(),
                                          jwtClaimsSet);
      // Compute the RSA signature
      signedJWT.sign(signer);
      return signedJWT.serialize();
   }

   public boolean verifyToken(String jwsToken) throws JOSEException, ParseException {
      SignedJWT signedJwt = SignedJWT.parse(jwsToken);
      return signedJwt.verify(new RSASSAVerifier(rsaJwkHolder.getRsaJwk()));
   }
}
