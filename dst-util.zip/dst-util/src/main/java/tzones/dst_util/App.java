package tzones.dst_util;

import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class App 
{
   private static final ZoneId NL_TIMEZONE = ZoneId.of("Europe/Amsterdam");
   private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

   public static void main( String[] args )
   {
      
       ZonedDateTime startDate = ZonedDateTime.of(2018, 3, 25, 01, 55, 00, 00, ZoneOffset.UTC);
       ZonedDateTime endDate = ZonedDateTime.of(2018, 3, 25, 03, 05, 00, 00, ZoneOffset.UTC);
       
      for(ZonedDateTime eachDay = startDate; eachDay.isBefore(endDate); eachDay = eachDay.plusMinutes(1)) {
         System.out.println(eachDay + " becomes " + eachDay.withZoneSameInstant(NL_TIMEZONE));
      }
    }
}
