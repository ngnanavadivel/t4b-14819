package tzones.dst_util;

import java.util.Deque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class App2 {
   public static void main(String[] args) {
      Deque<String> dq = null;
      ExecutorService pool = Executors.newFixedThreadPool(10);
   }
}
