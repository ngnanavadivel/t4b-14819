package com.gnanavad.utils;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailingUtility {
	public static void sendEmail(String fromEmailId, String fromEmailPassword, List<String> recepients, String subject,
			String body) {

		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(fromEmailId, fromEmailPassword);
			}
		});

		try {

			InternetAddress[] toAddresses = convertStringToInetAddresses(recepients);

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromEmailId));
			message.setRecipients(Message.RecipientType.TO, toAddresses);
			message.setSubject(subject);
			message.setText(body);

			Transport.send(message);

			System.out.println("Done");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	private static InternetAddress[] convertStringToInetAddresses(List<String> recepients) throws AddressException {
		InternetAddress[] addresses = null;
		if (!recepients.isEmpty()) {
			int size = recepients.size();
			addresses = new InternetAddress[size];
			for (int i = 0; i < size; ++i) {
				InternetAddress[] parsed = InternetAddress.parse(recepients.get(i));
				addresses[i] = (parsed != null && parsed.length > 0) ? parsed[0] : null;
			}
		}
		return addresses;
	}

	public static void main(String[] args) {
		final String fromEmailId = "mail2utillabs@gmail.com";
		final String fromEmailPassword = "Ut1l1ty$";
		List<String> recepients = Arrays
				.asList(new String[] { "nataraj.gnanavadivel@gmail.com", "geetha_mails@yahoo.com" });
		String subject = "Test Mail!!!";
		String body = "Happy Birthday, buddy!";
		MailingUtility.sendEmail(fromEmailId, fromEmailPassword, recepients, subject, body);
	}
}
