package com.gnanavad.utils;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class DailyJobScheduler {

	public static void main(String[] args) {
		Calendar today = Calendar.getInstance();

		// every night at 2am you run your task
		Timer timer = new Timer();
		timer.schedule(new BDayMailerTask("10.10.1980"), today.getTime(),
				TimeUnit.MILLISECONDS.convert(10, TimeUnit.SECONDS)); // period: 10 seconds

	}

}

class BDayMailerTask extends TimerTask {

	private String bday = null;

	public BDayMailerTask(String bday) {
		this.bday = bday;
	}

	@Override
	public void run() {
		Date parsed = null;
		try {
			parsed = BirthdayFinder.parseDate(this.bday);
			System.out.println(BirthdayFinder.isTodayABirthday(parsed) ? "Your birthday today!" : "Not Today!");
		} catch (ParseException e) {
			e.printStackTrace();
		}

	}

}