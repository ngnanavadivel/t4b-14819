package com.gnanavad.utils.model;

public class StudentDetails {
	private String name;
	private String batch;
	private String branchCode;
	private String dob;
	private String phoneNumber;
	private String emailAddress;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@Override
	public String toString() {
		return "StudentDetails [name=" + name + ", batch=" + batch + ", branchCode=" + branchCode + ", dob=" + dob
				+ ", phoneNumber=" + phoneNumber + ", emailAddress=" + emailAddress + "]";
	}

}
