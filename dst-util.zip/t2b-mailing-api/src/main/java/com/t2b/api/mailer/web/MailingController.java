package com.t2b.api.mailer.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.t2b.api.mailer.model.SendMailRequest;
import com.t2b.api.mailer.model.SendMailResponse;
import com.t2b.api.mailer.service.SendEmailService;

@RestController
public class MailingController {
   
   @Autowired
   SendEmailService service;
   
   @PostMapping(path="/send")
   public SendMailResponse sendEmail(@RequestBody SendMailRequest requestBody) {
      return service.sendMail(requestBody);
   }
}
