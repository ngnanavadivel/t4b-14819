package com.t2b.api.mailer.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Component;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.Base64;
import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.GmailScopes;
import com.google.api.services.gmail.model.Message;
import com.t2b.api.mailer.model.SendMailRequest;
import com.t2b.api.mailer.model.SendMailResponse;

@Component
public class SendEmailService {

   private static final String      APPLICATION_NAME = "t2b-support-mailer-v1";

   private static final JsonFactory JSON_FACTORY     = JacksonFactory.getDefaultInstance();

   public SendMailResponse sendMail(SendMailRequest request) {
      SendMailResponse response = SendMailResponse.builder()
         .status("SUCCESS")
         .description("Mail sent successfully!")
         .build();
      try {
         // Build a new authorized API client service.
         final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
         Gmail service = new Gmail.Builder(HTTP_TRANSPORT,
                                           JSON_FACTORY,
                                           getCredentials(HTTP_TRANSPORT))
                                              .setApplicationName(APPLICATION_NAME)
                                              .build();
         Message message = createMessageWithEmail(createEmail(request.getRecepients(),
                                                              request.getFrom(),
                                                              request.getSubject(),
                                                              request.getBody()));
         response.setStatus(service.users()
            .messages()
            .send(request.getFrom(), message)
            .execute()
            .getLabelIds()
            .contains("SENT") ? "SUCCESS" : "FALSE");
      }
      catch (Throwable t) {
         response = SendMailResponse.builder()
            .status("FAILED")
            .description(t.getMessage())
            .build();
      }
      return response;
   }

   private Message createMessageWithEmail(MimeMessage emailContent) throws MessagingException,
                                                                    IOException {
      ByteArrayOutputStream buffer = new ByteArrayOutputStream();
      emailContent.writeTo(buffer);
      return new Message().setRaw(Base64.encodeBase64URLSafeString(buffer.toByteArray()));
   }

   private MimeMessage createEmail(List<String> to,
                                   String from,
                                   String subject,
                                   String bodyText) throws MessagingException {
      MimeMessage email = new MimeMessage(Session.getDefaultInstance(new Properties(), null));
      email.setFrom(new InternetAddress(from));
      for (String each : to) {
         email.addRecipient(javax.mail.Message.RecipientType.TO, new InternetAddress(each));
      }
      email.setSubject(subject);
      email.setText(bodyText);
      return email;
   }

   /**
    * Creates an authorized Credential object.
    * 
    * @param HTTP_TRANSPORT
    *           The network HTTP Transport.
    * @return An authorized Credential object.
    * @throws IOException
    *            If the credentials.json file cannot be found.
    */
   private Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws Exception {
      return new GoogleCredential.Builder().setTransport(HTTP_TRANSPORT)
         .setJsonFactory(JSON_FACTORY)
         .setClientSecrets("573127012045-hjpel7qjihqv1kin5bnmgqn7q3kdtsae.apps.googleusercontent.com",
                           "DQ46frqyYESjzsvGqStfx7VK")
         .build()
         .setAccessToken("ya29.GltKBgen6H17t4LiC1fjOpzMlaB-GqXbjhWkTPW2T6llnO_pBIwkNCeUc_DY0UxbLwGeE-q1oAhHjxram9yhX54BCa2y6aQtxR572CHcG6F0ajtc1V_UQDLSds9s")
         .setRefreshToken("1/J_K1a_VNtp8NHKLzuIJIxiarwKnnWQhi6nXoHL2xUvg");
   }

   public static void main1(String... args) throws IOException, GeneralSecurityException {
      SendMailRequest request = SendMailRequest.builder()
         .from("support@ticket2beauty.com")
         .recepients(Arrays.asList(new String[] { "nataraj.gnanavadivel@gmail.com" }))
         .subject("Ticket2Beauty - Test Mail-01")
         .body("You are amazing!")
         .build();
      System.out.println(new SendEmailService().sendMail(request));
   }
}