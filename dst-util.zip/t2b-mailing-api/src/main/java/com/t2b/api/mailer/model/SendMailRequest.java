package com.t2b.api.mailer.model;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SendMailRequest {
   private String from;
   private List<String> recepients;
   private String subject;
   private String body;
}
